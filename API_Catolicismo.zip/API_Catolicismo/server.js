const express = require('express');
const app = express();
const port = 8765;
app.use(express.json());

app.listen(port, () => {
    console.log(`Servidor em execução: http://localhost:${port}/diocese`); // para que funcione deve ser usado crase
});

//Pessoas já cadastradas
let Pdiocese = [
    {id: 1, nome: 'Guilherme',  idade: 16, cargo: 'Leigo'},
    {id: 2, nome: 'Karyne', idade: 16, cargo: 'Leiga'},
    {id: 3, nome: 'Pe. Adailton', idade: 30, cargo: 'Padre'},
    {id: 4, nome: 'Pe. Sérgio', idade: 45, cargo: 'Padre'}
];

//Retorna todas as pessoas OK!!!
app.get('/diocese',
     (req, res) => {
    res.json(Pdiocese);
});

//Quantidade cadastrada OK!!!!!
app.get('/quantidade', (req, res) => {
    res.json({ quantidade: Pdiocese.length });
});

//Retorna o primeiro cadastrado OK!!!!
app.get('/diocese/primeiro', (req, res) => {
    if(Pdiocese.length > 0){
        res.json(Pdiocese[0]);
    }else{
        res.status(404).json({ erro: "Nenhuma pessoa cadastrada" });
    }
});

//Retorna o último cadastrado OK!!!!!!
app.get('/diocese/ultimo', (req, res) => {
    if(Pdiocese.length > 0){
        res.json(Pdiocese[Pdiocese.length - 1]);
    }else{
        res.status(404).json({ erro: "Nenhuma pessoa cadastrada" });
    }
});

// Retorna dados estatísticos Ok!!!!
app.get('/diocese/estatisticas', (req, res) => {
    if (Pdiocese.length === 0) {
        return res.status(404).json({ erro: "Nenhuma pessoa cadastrada" });
    }
    const totalIdade = Pdiocese.reduce((soma, pessoa) => soma + pessoa.idade, 0); // soma idades
    const mediaIdade = totalIdade / Pdiocese.length;
    res.json({ mediaIdade: parseFloat(mediaIdade.toFixed(2)) });
});

//Busca pessoas OK!!!
app.get('/diocese/:id', (req,res) => {
    const id = parseInt (req.params.id);
    const pessoa = Pdiocese.find(d => d.id === id );
    if(pessoa){ 
        res.json(pessoa);
    }else{
        res.status(404).json({erro: 'Pessoa da diocese não encontrada'});
    }
});

//AdicionaPessoa OK!!!!
    app.post('/diocese', (req, res) => {
    const { nome, idade, cargo } = req.body;
    if (!nome || !idade || !cargo) {
        return res.status(400).json({ erro: "Campos obrigatórios: nome, idade, cargo" });
    }
    const novaPessoa = {
        id: Pdiocese.length + 1,
        nome: nome,
        idade: idade,
        cargo: cargo
    }
    Pdiocese.push(novaPessoa);
    res.status(201).json(novaPessoa)
})

//Atualizar Pessoa OK!!!!
app.put('/diocese/:id', (req,res) => {
    const id = parseInt (req.params.id);
    const pessoa = Pdiocese.find(d => d.id === id );
    if(pessoa){ 
        const { nome, idade, cargo } = req.body;
        if (nome) pessoa.nome = nome;
        if (idade) pessoa.idade = idade;
        if (cargo) pessoa.cargo = cargo;
        res.json(pessoa);
    }else{
        res.status(404).json({erro: 'Pessoa da diocese não encontrada'});
    }
});
 
//Deleta pessoa OK!!!!!
app.delete('/diocese/:id', (req,res) => {
    const id = parseInt (req.params.id);
    const index = Pdiocese.findIndex(d => d.id === id );
    if(index !== -1){ 
        const pessoaDioceseDeletada = Pdiocese.splice(index, 1);
        res.json(pessoaDioceseDeletada[0]);
    }else{
        res.status(404).json({erro: 'Pessoa da diocese não encontrada'});
    }
});

//Quantidade de pessoas cadastradas com idade de < 25 OK!!!!
app.get('/diocese/idade/menor25', (req, res) => {
    const menor25 = Pdiocese.filter(d => d.idade < 25);
    res.json(menor25);
});

//Filtra por cargo OK!!!!!
app.get('/diocese/cargo/:cargo', (req, res) => {
    const cargo = req.params.cargo;
    const filtradas = Pdiocese.filter(d => d.cargo === cargo);
    if(filtradas.length > 0){ 
        res.json(filtradas);
    }else{
        res.status(404).json({ erro: "Nenhuma pessoa com esse cargo encontrada" });
    }
});

// Cadastra varias pessoas de uma vez OK!!!
app.post('/diocese/multiC', (req, res) => { 
    const pessoas = req.body;

    if (!Array.isArray(pessoas)) {
        return res.status(400).json({ erro: "Deve enviar um array" });
    }
    const novasPessoas = [];
    for (const pessoaN of pessoas) {
        const { nome, idade, cargo } = pessoaN;
        if (!nome || !idade || !cargo) {
            return res.status(400).json({ erro: "Campos obrigatórios: nome, idade, cargo" });
        }
        const novaPessoa = {
            id: Pdiocese.length + 1,
            nome: nome,
            idade: idade,
            cargo: cargo
        };
        Pdiocese.push(novaPessoa);
        novasPessoas.push(novaPessoa); // Adiciona à lista de novas pessoas
    }
    res.status(201).json(novasPessoas); // retorna apenas as pessoas adicionadas
});